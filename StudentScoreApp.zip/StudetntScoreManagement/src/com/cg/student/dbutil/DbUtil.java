package com.cg.student.dbutil;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DbUtil {
	
	static Connection connection;

	public static Connection obtainConnection()  {
		try {
			InitialContext context = new InitialContext();
			DataSource source = (DataSource) context.lookup("java:/govind");
			connection = source.getConnection();
		}
		catch (NamingException e) 
		{
			e.getMessage();
		}
		catch (SQLException e)
		{
			 e.getMessage();
		}
		return connection;
	}

}

package com.cg.student.dao;

import java.util.ArrayList;

import com.cg.student.bean.StudentBean;
import com.cg.student.exception.StudentException;

public interface IStudentDao {

	public ArrayList<Integer> getStudentId() throws StudentException;

	public int addStudentDetails(StudentBean bean) throws StudentException;

}

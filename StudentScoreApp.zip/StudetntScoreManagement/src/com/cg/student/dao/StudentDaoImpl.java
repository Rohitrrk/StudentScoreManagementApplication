package com.cg.student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.jboss.logging.Logger;

import com.cg.student.bean.StudentBean;
import com.cg.student.dbutil.DbUtil;
import com.cg.student.exception.StudentException;

public class StudentDaoImpl  implements IStudentDao{

	
	Logger log = Logger.getLogger(StudentDaoImpl.class);
	
	Connection con = null;
	@Override
	public ArrayList<Integer> getStudentId() throws StudentException {
		
		
		
		
		ArrayList<Integer> list = null;	
		try {
			con = DbUtil.obtainConnection();
			System.out.println(con);
			list = new ArrayList<Integer>();
			String sql = "Select student_id from Student";
			
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			
			while(rs.next())
			{
				list.add(rs.getInt(1));
			}
		
			
		} 
		catch (SQLException e) {
			
			throw new StudentException(e.getMessage());
		}
		
		return list;
	}

	@Override
	public int addStudentDetails(StudentBean bean) throws StudentException {
		int row = 0;
		try {
			con = DbUtil.obtainConnection();
			
			String insert = "INSERT INTO Student_Scores VALUES(?,?,?,?,?,?,?)";
			PreparedStatement pst = con.prepareStatement(insert);
		
			
			pst.setInt(1, bean.getStudent_id());
			pst.setString(2, bean.getSubjectName());
			pst.setInt(3, bean.getTheory());
			pst.setInt(4, bean.getMcq());
			pst.setInt(5, bean.getLab());
			pst.setInt(6, bean.getTotalScores());
			pst.setString(7, bean.getGrade());
			
			row = pst.executeUpdate();
			if(row == 1)
			{
				log.info("inserted successfully in logger");
				
			}
			
			}
			
			catch (SQLException e) {
				
				throw new StudentException(e.getMessage());

							}
			
			return row;
		
		
	}

}

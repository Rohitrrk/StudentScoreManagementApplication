package com.cg.student.bean;

public class StudentBean {
	
	private int student_id;
	private String subjectName;
	private int theory;
	private int mcq;
	private int lab;
	private int totalScores;
	private String grade;
	
	
	public int getStudent_id() {
		return student_id;
	}
	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public int getTheory() {
		return theory;
	}
	public void setTheory(int theory) {
		this.theory = theory;
	}
	public int getMcq() {
		return mcq;
	}
	public void setMcq(int mcq) {
		this.mcq = mcq;
	}
	public int getLab() {
		return lab;
	}
	public void setLab(int lab) {
		this.lab = lab;
	}
	public int getTotalScores() {
		return totalScores;
	}
	public void setTotalScores(int totalScores) {
		this.totalScores = totalScores;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}

	
	
}

package com.cg.student.service;

import java.util.ArrayList;

import com.cg.student.bean.StudentBean;
import com.cg.student.exception.StudentException;

public interface IStudentService {

	public ArrayList<Integer> getStudentId() throws StudentException;

	public int addStudentDetails(StudentBean bean) throws StudentException;

	public String grade(int total);

	public int total(int theory, int mcq, int lab);

}

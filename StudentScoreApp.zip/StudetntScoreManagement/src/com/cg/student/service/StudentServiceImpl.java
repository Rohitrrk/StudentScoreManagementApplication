package com.cg.student.service;

import java.util.ArrayList;

import com.cg.student.bean.StudentBean;
import com.cg.student.dao.IStudentDao;
import com.cg.student.dao.StudentDaoImpl;
import com.cg.student.exception.StudentException;

public class StudentServiceImpl implements IStudentService
{

	IStudentDao dao = new StudentDaoImpl();
	
	@Override
	public ArrayList<Integer> getStudentId() throws StudentException {
		
		return dao.getStudentId();
	}
	
	
	@Override
	public int addStudentDetails(StudentBean bean) throws StudentException {
		
		return dao.addStudentDetails(bean);
	}
	
	
	@Override
	public String grade(int total) {
		String grade = null;
		if(total >= 91 && total <=100)
		{
			grade = "S";
		}
		else if(total >= 81 && total <=90)
		{
			grade = "A";
		}
		
		else if(total >= 71 && total <=80)
		{
			grade = "B";
		}
		
		else if(total >= 61 && total <=70)
		{
			grade = "C";
		}
		
		else if(total >= 50 && total <=60)
		{
			grade = "D";
		}		
		else 
		{
			grade = "U";
		}
		
		return grade;
	}
	
	
	@Override
	public int total(int theory, int mcq, int lab) {
		
		int total=(theory+mcq+lab);
		return total;
	}

}

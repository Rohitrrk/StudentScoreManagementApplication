/*
 * 
 */

function check()
{
	var studId = document.forms[0].studentId.value;
	var theory = document.forms[0].theory.value;
	var mcq = document.forms[0].mcq.value;
	var lab = document.forms[0].lab.value;
	var total =theory + mcq + lab;
	
	if(studId == "1")
		{
			alert("Please select Student id !!");
			document.forms[0].studentId.focus;
			return false;
		}
		
		if(isNaN(theory))
		{
			alert("Theory marks must be integer");
			 document.forms[0].theory.focus;
			return false;
		}	
		if(isNaN(mcq))
			{
			alert("MCQ's marks must be integer");
			 document.forms[0].mcq.focus;
			return false;
			}
		if(isNaN(lab))
			{
			alert("Lab marks must be integer");
			 document.forms[0].lab.focus;
			return false;
			}
		if(theory < 0 || theory > 70)
			{
			alert("Theory marks must be in range 0-70 only");
			return false;
			}
		if(mcq < 0 || mcq > 15)
		{
		alert("MCQ's marks must be in range 1-15 only");
		return false;
		}
		
		if(lab < 0 || lab > 15)
		{
		alert("Lab marks must be in range 1-15 only");
		return false;
		}
		
		if(total >= 100)
			{
			 alert("Addition of Theory, MCQ's,Lab marks must be less than 100 !!!");
			 return false;
			}
	
	return true;
	
}
